#include <iostream>
#include <thread>
#include <mutex>
#include <chrono>
#include <atomic>
#include "vector"
inline std::chrono::high_resolution_clock::time_point get_current_time_fenced()
{
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::high_resolution_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}

template<class D>
inline long long to_us(const D& d)
{
    return std::chrono::duration_cast<std::chrono::microseconds>(d).count();
}

long long oneStream(long long n){
    long long number = 0;
    for(int x = 0; x < n;x++ ){
        for(int y = 0; y < n;y++ ){
            for(int z = 0; z < n;z++ ){
                if( 60 * (x*z+z*y+x*y ) == 4*x*y*z){
                    number+=1;

                }
            }
        }
    }

    return number;
}

void countNumber(long long n,long long start, long long end, std::mutex& m, long long &resalt){
    //mutex help to work with threads...

    long long number1 = 0;
    for(int x = start; x < end;x++ ) {
        for (int y = 0; y < n; y++) {
            for (int z = 0; z < n; z++) {
                if (60 * (x * z + z * y + x * y) == 4 * x * y * z) {
                    number1 += 1;
                }
            }
        }
    }
    m.lock();
    resalt += number1;
    m.unlock();


}


int main(){
/*
    const int n  = 3;
    long long lim = (5*5)/n;

    for(int i=0;i<n;i++){
        std::cout << lim*i  << " " << lim*(i+1) << std::endl;
    }

    return 0;
 */

    std::cout<< "Begin"<<std::endl;
    auto stage1_start_time = get_current_time_fenced();
    std::cout<< "oneStream do ..."<<std::endl;
    long long number = oneStream(3600);
    std::cout<< "oneStream end"<<std::endl;
    auto stage2_start_time = get_current_time_fenced();
    auto stage1_time = stage2_start_time - stage1_start_time;

    int Nthreads = 10;
    std::vector<std::thread> threads;
    std::mutex m;
    long long limit = (3600)/Nthreads;
    long long result = 0;
    long long start = 0;
    long long end = limit;

    for(int i=0;i<Nthreads;i++)
    {
        threads.emplace_back(std::thread(countNumber,3600, start, end, std::ref(m), std::ref(result)));
        start += limit;
        end += limit;
    }
    for(auto& thread: threads){
        thread.join();
    }
    auto final = get_current_time_fenced();
    auto stage2_time = final - stage2_start_time;
    float finish1 = to_us(stage1_time);
    float finish2 = to_us(stage2_time);
    std::cout<< finish1 / 1000000 <<std::endl;
    std::cout<< finish2 / 1000000 <<std::endl;
    bool key = result == number;
    printf("The results of Oneproces and threads are \n");
    std::cout<< result <<std::endl;
    std::cout<< number <<std::endl;

    return 0;
}